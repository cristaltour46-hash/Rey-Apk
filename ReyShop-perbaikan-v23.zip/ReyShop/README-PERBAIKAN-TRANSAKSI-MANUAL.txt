Pembaruan transaksi berdasarkan ZIP dasar 27 Oktober 2026.
- Pencarian manual tanpa hasil menampilkan opsi tambah barang manual.
- Barcode tidak dikenal meminta konfirmasi; jika disetujui, barang masuk ke keranjang dengan nama awal berupa barcode.
- Nama barang dapat diedit langsung pada baris keranjang.
- Penjualan melebihi stok meminta konfirmasi dan dapat dilanjutkan.
Catatan: belum diuji pada perangkat Android; periksa melalui build/test sebelum dipakai.
