Rey Shop v17 - perbaikan pembaca barcode dan form

1. Pembaca alternatif ZXing menggunakan elemen video dan stream kamera yang sudah aktif, sehingga tidak mencoba membuka stream kamera kedua. Pustaka alternatif tetap memerlukan koneksi internet jika belum tersimpan di cache.
2. Tombol Batal dan Simpan transaksi kembali menjadi bagian normal dari form (bukan sticky/fixed), sehingga ikut bergulir bersama isi form.
3. Semua modal/form memiliki batas tinggi sesuai viewport dan jarak bawah 10 dp ditambah safe-area Android; isi form dapat digulir dan tombol tidak menempel pada tepi layar.
4. Kamera ditutup otomatis setelah 60 detik jika belum ada barcode yang berhasil dibaca. Setelah pembacaan pertama, kamera tetap aktif sampai ditutup manual.

Sumber aplikasi: index.html dan android-wrapper/app/src/main/assets/index.html. Buat APK melalui paket builder dan uji kamera pada perangkat Android nyata.
