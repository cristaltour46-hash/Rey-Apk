REY SHOP - ASISTEN LOKAL TAHAP 1

Perubahan pada tahap ini:
- Menambahkan tab Asisten pada antarmuka Rey Shop.
- Menambahkan jawaban lokal berbasis aturan untuk pertanyaan stok minimum, pencarian barang, ringkasan penjualan hari ini, pembelian hari ini, total nilai catatan hutang, dan jumlah barang di katalog.
- Jawaban menggunakan data lokal yang telah dimuat oleh aplikasi. Tidak ada permintaan jaringan atau API AI yang ditambahkan.
- Menyalin index.html yang sama ke android-wrapper/app/src/main/assets/index.html.
- Tidak mengubah konfigurasi workflow GitHub Actions.

PENTING:
Tahap 1 ini adalah fondasi asisten offline berbasis aturan, BUKAN model bahasa generatif/LLM. Runtime model lokal belum dipasang. Label ini ditampilkan di UI agar kemampuan tidak disalahartikan.

Catatan akurasi:
- Ringkasan transaksi saat ini menjumlahkan baris transaksi tersimpan, bukan jumlah nomor nota unik.
- Total hutang merupakan total nilai baris catatan hutang yang tersimpan, bukan saldo setelah pembayaran.
- Pertanyaan yang belum didukung diberi penjelasan dan contoh pertanyaan yang didukung, bukan jawaban yang dibuat-buat.

Uji yang dilakukan:
- Memeriksa sintaks JavaScript dengan Node.js --check.
- Belum membangun atau menguji APK Android di perangkat.

Langkah berikutnya sebelum memasang model generatif offline:
1. Konfirmasi versi Android/arsitektur CPU perangkat target dan ruang penyimpanan tersedia.
2. Pilih runtime/model yang kompatibel dengan proyek Gradle yang ada.
3. Integrasikan runtime melalui Java bridge dengan batas memori dan penanganan gagal-muat.
4. Uji waktu muat, RAM, panas, respons, dan penggunaan data lokal sebelum menyatakan siap pakai.
