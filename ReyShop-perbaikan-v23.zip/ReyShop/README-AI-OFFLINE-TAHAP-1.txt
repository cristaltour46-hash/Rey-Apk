REY SHOP — INTEGRASI AI LOKAL UJI COBA (ANDROID)

Perubahan pada source: 
- Menambahkan dependency LiteRT-LM Android 0.18.0 dan Kotlin Android plugin.
- Menambahkan LocalAiBridge.kt untuk memilih file model .litertlm, menyimpan salinan privat di filesDir, memuat model di thread latar belakang, dan mengirim pertanyaan ke model.
- Menghubungkan menu Asisten ke bridge native saat berjalan di APK Android.
- Tetap mempertahankan jawaban berbasis aturan sebagai fallback saat model belum tersedia.
- Menyamakan index.html pada folder web dan Android assets.
- Tidak mengubah GitHub Actions workflow.

PENTING UNTUK PENGUJIAN: ini source uji integrasi, BUKAN APK yang sudah terverifikasi. Lingkungan kerja ini tidak memiliki Gradle/Android SDK yang dapat dipakai untuk membangun APK, jadi build Android belum dapat diverifikasi.

MODEL: berkas .litertlm tidak disertakan di ZIP/APK. Model bahasa berukuran ratusan MB hingga beberapa GB; panduan Android LiteRT-LM menyarankan model diletakkan sebagai file pada penyimpanan perangkat, bukan assets/APK. Untuk menguji AI generatif, siapkan model .litertlm yang kompatibel dengan LiteRT-LM (misalnya Qwen3-0.6B versi LiteRT-LM dari LiteRT Community) lalu pilih dari tombol “Pilih / impor model AI (.litertlm)” di menu Asisten. Impor model membutuhkan berkas itu tersedia di perangkat. Setelah tersimpan, inferensi model berlangsung lokal/offline.

LANGKAH UJI: 
1. Unggah ZIP ini ke repositori sesuai alur GitHub Actions yang sudah digunakan. Workflow tidak diubah.
2. Jalankan workflow untuk mencoba build APK. Jika gagal, kirim log build lengkap untuk diperbaiki.
3. Instal APK debug pada Android 15.
4. Salin model .litertlm yang kompatibel ke perangkat (dapat melalui komputer/kabel atau cara transfer file yang biasa dipakai).
5. Buka Asisten > Pilih / impor model AI (.litertlm), pilih file, tunggu pemuatan selesai, lalu ajukan pertanyaan.
6. Uji mode pesawat setelah model berhasil dimuat untuk memastikan inferensi berjalan offline.

BATASAN: kode integrasi ini belum dapat dikompilasi atau diuji di perangkat dalam lingkungan ini. Nama API runtime mengikuti dokumentasi LiteRT-LM Kotlin; jika workflow menemukan error compile, log tersebut diperlukan untuk menyesuaikan API/dependency tepat dengan versi yang diunduh. RAM 6 GB tidak menjamin semua model lancar; mulai dari model kecil dan ukur waktu muat, RAM, suhu, serta respons di perangkat.
