REY SHOP v32.2

Perbaikan berdasarkan pemeriksaan paket v32 yang diunggah pengguna.
- Menyamakan android-wrapper/app/src/main/assets/index.html dengan source utama ReyShop/index.html.
- Ini memastikan Android WebView memuat halaman yang sama dengan source v32 (dashboard dan laporan).
- Workflow GitHub Actions tidak diubah. Saat mengunggah, gunakan nama file yang diwajibkan workflow repositori Anda.

Catatan: APK belum dibangun atau diuji pada perangkat; uji hasil build setelah mengunggah paket.
