REY SHOP v19 - PERBAIKAN TOMBOL TRANSAKSI

- Menambahkan tombol Edit dan Hapus pada setiap baris transaksi penjualan dan pembelian.
- Edit memuat seluruh item pada nomor transaksi yang sama, bukan hanya satu baris.
- Hapus menghapus seluruh transaksi dalam satu invoice dan menyesuaikan stok untuk setiap item.
- Perubahan diterapkan pada index.html utama dan aset Android.

Uji APK pada perangkat sebelum dipakai untuk transaksi nyata.


PERBAIKAN V20
- Semua tabel aplikasi dibatasi maksimal 10 baris per halaman.
- Navigasi Sebelumnya/Berikutnya dan jumlah baris ditampilkan jika diperlukan.
- Berlaku untuk tabel dashboard, transaksi jual/beli, laporan, dan tabel dalam form.
