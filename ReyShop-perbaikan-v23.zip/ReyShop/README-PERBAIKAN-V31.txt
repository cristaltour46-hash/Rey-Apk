REY SHOP v31

Perubahan utama:
- Mempertahankan ringkasan laporan yang sudah ada di v30, termasuk omzet, modal barang terjual, estimasi laba kotor, total pembelian, dan estimasi nilai persediaan.
- Mengganti tabel rincian Penjualan dan Pembelian lama di halaman Laporan dengan Pencarian Barang & Catatan Transaksi dan Ringkasan Transaksi per Barang.
- Pencarian laporan memakai pencocokan sebagian (substring), tidak peka huruf besar/kecil, pada nama barang atau catatan transaksi.
- Hasil pencarian ditampilkan dalam tabel ringkas dengan tombol Lihat Detail.
- Ringkasan per barang menyediakan filter periode yang sama, dropdown jenis transaksi Penjualan/Pembelian, autocomplete barang, total nota unik, total qty, total nilai barang, serta tabel transaksi dengan Lihat Detail.
- Fitur lain dari v30 dipertahankan; versi aplikasi dinaikkan menjadi 31.0 (versionCode 31).

Catatan pengujian:
- Source package dan workflow builder disiapkan untuk build APK melalui GitHub Actions.
- APK belum dibangun atau diuji pada perangkat Android dalam lingkungan ini. Setelah upload ke GitHub, jalankan workflow build-apk.yml dan uji fitur pada perangkat.
