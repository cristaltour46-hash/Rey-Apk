Rey Shop v14 - pembaruan pemindai dan transaksi.

Perubahan: kamera form tambah barang ditutup setelah scan berhasil; panel kamera transaksi menempel di bagian atas modal saat form digulir; scan barcode produk yang sudah ada di keranjang dilewati dengan notifikasi; daftar keranjang digulirkan ke tampilan setelah scan berhasil; input harga dan qty otomatis terseleksi saat disentuh; notifikasi melayang dipindah ke bagian atas.

Bangun APK menggunakan paket builder v14. Pengujian kamera langsung di perangkat tetap diperlukan.
