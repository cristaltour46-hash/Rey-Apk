Rey Shop v15 - perbaikan pembaca barcode alternatif menggunakan ZXing dengan TRY_HARDER dan daftar format barcode umum; tombol Batal/Simpan transaksi dibuat sticky di bawah modal penjualan/pembelian agar mudah disentuh; kolom Qty dan Harga pada setiap baris keranjang otomatis menyeleksi seluruh nilai saat disentuh/difokuskan.

Paket sumber. Bangun APK menggunakan workflow GitHub Actions pada paket builder. Kamera/barcode tetap perlu diuji di perangkat Android nyata.
