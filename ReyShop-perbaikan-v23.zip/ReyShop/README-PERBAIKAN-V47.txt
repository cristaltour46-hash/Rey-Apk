Rey Shop v47: perbaikan popup pilihan barcode ganda, ringkasan laporan responsif, dan penghapusan tombol Tampilkan ringkasan barang. Form Hutang v44 dan workflow GitHub Actions tidak diubah.
