PERBAIKAN REY SHOP

1. Menu Asisten AI dihapus dari navigasi dan kode pemanggil AI/Gemini dihapus.
2. Saat aplikasi dibuka, API key Gemini dan penghitung pemakaian lokal yang pernah disimpan akan dihapus dari localStorage.
3. Transaksi penjualan/pembelian: pengguna dapat mengetik nama barang yang belum terdaftar, mengisi harga dan qty, lalu menekan tombol “Tambah item / buat barang baru”. Barang baru dibuat dengan stok awal 0 dan langsung dimasukkan ke keranjang.
4. Penjualan melebihi stok tetap memunculkan konfirmasi sebelum transaksi disimpan.
5. Form Hutang, halaman Laporan, dan workflow GitHub Actions tidak sengaja diubah.

ZIP diperiksa integritasnya. APK dan uji transaksi di perangkat belum dijalankan.
