REY SHOP V18

Perubahan:
- Menghapus pembaca barcode alternatif ZXing dan seluruh pemanggilan CDN terkait dari pemindai kamera.
- Pemindaian kamera hanya menggunakan BarcodeDetector bawaan perangkat.
- Jika perangkat tidak mendukung BarcodeDetector, aplikasi menampilkan pesan yang jelas; input barcode manual tetap dapat digunakan.
- Perubahan form dan timer penutupan kamera dari v17 dipertahankan.

Catatan: BarcodeDetector tidak tersedia pada semua versi WebView/perangkat Android. Uji di perangkat sasaran setelah build.
