REY SHOP v23 — PERBAIKAN PAKET APK

Perbaikan penting pada paket ini:
- index.html versi terbaru disalin ke android-wrapper/app/src/main/assets/index.html agar APK memuat perubahan yang sama dengan kode sumber web.
- Laporan menampilkan omzet, modal barang terjual, estimasi laba kotor, margin, total pembelian, rata-rata transaksi, dan selisih omzet-pembelian.
- Form transaksi menempatkan tombol scan kamera di baris atas, menyembunyikan input barcode manual, dan menata tanggal serta nomor transaksi dalam satu baris.
- Subtotal dan total transaksi diperbarui langsung saat qty/harga berubah; kembalian juga ikut dihitung ulang.
- Nama barang panjang di keranjang dipotong dengan elipsis agar tabel lebih ringkas.
- Versi Android dinaikkan ke versionCode 10 / versionName 1.3.0 agar dapat memperbarui APK sebelumnya.

Catatan: APK harus dibangun ulang dari paket ini melalui GitHub Actions. Periksa hasil build dan uji transaksi di perangkat.
