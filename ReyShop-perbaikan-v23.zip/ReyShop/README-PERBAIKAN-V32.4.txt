Rey Shop v32.4

Perbaikan berdasarkan v32.3:
- Zoom grafik memakai dua jari dengan skala horizontal; grafik 7/30 hari mulai di ujung kanan (hari ini).
- Nilai transaksi muncul pada pop-up dengan warna sesuai batang grafik.
- Lebar dropdown jenis transaksi 100%.
- Kamera Setting dipasang fixed di bagian atas layar.
- Tabel pencarian laporan tidak ditampilkan sebelum pengguna menekan Cari transaksi.

Workflow GitHub Actions tidak diubah.
