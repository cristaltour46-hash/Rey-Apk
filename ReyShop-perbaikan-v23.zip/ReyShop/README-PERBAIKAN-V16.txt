Rey Shop v16 - pembaruan form dan posisi tombol

1. Kolom input teks/angka dan textarea otomatis menyeleksi seluruh isi saat disentuh/fokus agar mudah diganti; semua input, pilihan, dan textarea menampilkan highlight fokus yang jelas.
2. Area kamera barcode sedikit diperkecil: kamera transaksi 220 px dan tambah barang 240 px, dengan batas tinggi layar lebih rendah.
3. Tombol Batal dan Simpan transaksi pada form penjualan/pembelian diposisikan sticky dengan jarak bawah 10 dp pada area form, termasuk memperhitungkan safe area Android.

Paket sumber. Untuk menghasilkan APK, gunakan paket builder dan workflow GitHub Actions. Periksa kembali pada perangkat Android nyata, terutama posisi tombol di atas navigasi sistem.
