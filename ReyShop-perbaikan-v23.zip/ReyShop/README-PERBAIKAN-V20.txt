REY SHOP - PERBAIKAN V20

- Semua tabel aplikasi menampilkan maksimal 10 baris per halaman.
- Navigasi Sebelumnya/Berikutnya muncul saat jumlah baris lebih dari 10.
- Tersedia informasi jumlah baris yang sedang ditampilkan.
- Berlaku untuk tabel dashboard, transaksi penjualan/pembelian, laporan, dan tabel dalam form.
- Kode HTML aplikasi dan aset Android disamakan.

Catatan: paket sumber belum merupakan APK yang telah diuji di perangkat Android. Build APK melalui GitHub Actions dan lakukan pengujian sebelum dipakai untuk transaksi nyata.
