# Rey Shop — Paket aplikasi

## Fitur
- Dashboard: ringkasan penjualan, pembelian, estimasi laba kotor, dan stok menipis.
- Penjualan: tambah, edit, hapus transaksi; stok berkurang otomatis.
- Pembelian: tambah, edit, hapus transaksi; stok bertambah otomatis.
- Laporan berdasarkan tanggal awal dan akhir, dengan ekspor CSV.
- Setting: kelola barang, harga modal/jual, stok awal, batas minimum, nama toko, cadangan/pulihkan data JSON.
- Data tersimpan lokal di perangkat/browser.

## Cara mencoba sekarang
Buka `index.html` di browser. Untuk pengalaman seperti aplikasi dan dukungan offline yang lebih baik, host folder ini melalui HTTPS, buka dari Chrome Android, lalu pilih menu browser **Tambahkan ke layar utama / Install app**.

## Tentang APK
Paket ini belum berisi APK yang sudah dikompilasi. Lingkungan pembuatan saat ini tidak memiliki Android SDK/Gradle untuk menghasilkan dan menguji file APK. Folder `android-wrapper` berisi kerangka Android WebView untuk proyek Android Studio; diperlukan Android SDK dan proses build/signing untuk menghasilkan APK. Jangan menginstal APK dari sumber yang tidak dikenal.

## Fitur barcode, keranjang, dan struk (versi diperbarui)
- Barang memiliki kolom barcode dan tombol scan kamera.
- Penjualan/pembelian mendukung banyak item dalam satu nomor transaksi, melalui pilih barang manual atau barcode.
- Struk per transaksi bisa dibuka dan dicetak melalui dialog cetak browser.
- Scan kamera memerlukan browser Android yang mendukung `BarcodeDetector`, izin kamera, dan konteks aman (HTTPS) atau konfigurasi WebView Android yang sesuai. Jika tidak didukung, barcode dapat dimasukkan manual atau dengan scanner Bluetooth/USB.
- Kerangka Android telah ditambahkan izin kamera, tetapi tetap perlu dibangun dan diuji menggunakan Android Studio/SDK; belum berupa APK terkompilasi.


## Perbaikan kamera APK (sumber diperbarui)
- Android WebView sekarang memuat halaman melalui `https://appassets.androidplatform.net/assets/index.html` menggunakan AndroidX WebViewAssetLoader, bukan `file:///android_asset/index.html`. Ini membantu menyediakan secure origin untuk `getUserMedia()`.
- `MainActivity.java` memeriksa origin halaman, hanya memberikan resource `VIDEO_CAPTURE`, dan menunggu hasil izin kamera Android sebelum memberi izin kepada WebView.
- `app/build.gradle` menambahkan dependensi `androidx.webkit:webkit:1.12.1`.
- Pesan kegagalan scan sekarang menampilkan nama error di logcat/pesan sehingga diagnosis lebih mudah.

### Membangun dan menguji APK
1. **Sebelum mengganti APK yang sudah dipakai, buka Setting dan ekspor/cadangkan data JSON.** Mengubah origin WebView dapat membuat data `localStorage` dari versi lama tidak langsung terlihat pada versi baru.
2. Buka folder `android-wrapper` melalui Android Studio.
3. Sinkronkan Gradle dan bangun APK (`Build > Build APK(s)`).
4. Pasang APK di HP, lalu izinkan kamera pada dialog Android.
5. Uji scan barcode. Jika muncul pesan bahwa `BarcodeDetector` tidak didukung, itu adalah masalah dukungan decoder terpisah: proyek ini saat ini memakai Barcode Detection API bawaan WebView/browser. Untuk kompatibilitas yang lebih luas, integrasikan decoder JavaScript yang dibundel lokal (mis. ZXing) atau decoder native Android.
6. Paket ini tetap berupa kode sumber, bukan APK yang telah dikompilasi atau diuji di perangkat fisik.

## Pembaruan v23
- Laporan menampilkan omzet, modal barang terjual, estimasi laba kotor, margin laba, jumlah transaksi, rata-rata omzet per transaksi, total pembelian stok, dan selisih omzet-pembelian.
- Form jual/beli menempatkan tombol buka kamera pada baris paling atas; input barcode dan tombol tambah di sebelahnya dihilangkan agar lebih lega. Input manual barang tetap tersedia di bawahnya.
- Tanggal dan nomor transaksi tetap sejajar dalam satu baris pada layar yang cukup lebar.
- Subtotal, total transaksi, dan kembalian diperbarui langsung saat qty atau harga di keranjang berubah.
- Nama barang panjang dipotong dengan elipsis di keranjang; nama penuh tetap tersedia saat disentuh/ditahan melalui tooltip browser.
- Laporan laba adalah estimasi laba kotor, bukan laba bersih; biaya operasional belum dihitung.
