Rey Shop v33

- Draft Penjualan/Pembelian disimpan lokal, dapat dibuka/dihapus, tidak memengaruhi stok sebelum transaksi disimpan.
- Form transaksi memiliki tanggal dan jam terpisah.
- Menu Hutang Pelanggan menyimpan item secara terpisah dan tidak mengubah stok atau laporan penjualan/pembelian.
- Workflow GitHub Actions tidak diubah.

Catatan: uji fungsional pada perangkat Android tetap diperlukan.
