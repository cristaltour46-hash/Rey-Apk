package id.reyshop.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.Arrays;

public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION_REQUEST = 45;
    private static final int CREATE_BACKUP_REQUEST = 46;
    private static final int OPEN_BACKUP_REQUEST = 47;
    private String pendingBackupJson = "";
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private WebView web;
    private PermissionRequest pendingCameraRequest;
    private WebViewAssetLoader assetLoader;
    private LocalAiBridge localAiBridge;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setLayoutParams(new android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });

        web.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        web.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        localAiBridge = new LocalAiBridge(this, web);
        web.addJavascriptInterface(localAiBridge, "AndroidLocalAI");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingCameraRequest == request) {
                    pendingCameraRequest = null;
                }
            }
        });

        setContentView(web);
        // HTTPS-like trusted origin supplied by WebViewAssetLoader; avoids file:// origin
        // restrictions that commonly prevent getUserMedia() from opening the camera.
        web.loadUrl(APP_ORIGIN + "/assets/index.html");
    }


    private class ShareBridge {
        @JavascriptInterface
        public void shareImage(String base64Png, String filename) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Png, Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME,
                            filename == null ? "rey-shop-struk.png" : filename);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Rey Shop");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    }
                    Uri imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (imageUri == null) throw new java.io.IOException("Tidak dapat membuat gambar struk");
                    try (OutputStream out = getContentResolver().openOutputStream(imageUri)) {
                        if (out == null) throw new java.io.IOException("Tidak dapat menyimpan gambar struk");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues ready = new ContentValues();
                        ready.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(imageUri, ready, null, null);
                    }
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_STREAM, imageUri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Kirim gambar struk melalui"));
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "Gagal membagikan gambar struk: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(send, "Kirim struk melalui"));
            });
        }
    }

    private class BackupBridge {
        @JavascriptInterface
        public void saveBackup(String filename, String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json == null ? "{}" : json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename == null ? "rey-shop-cadangan.json" : filename);
                startActivityForResult(intent, CREATE_BACKUP_REQUEST);
            });
        }

        @JavascriptInterface
        public void openRestore() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream"});
                startActivityForResult(intent, OPEN_BACKUP_REQUEST);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LocalAiBridge.MODEL_REQUEST) {
            if (localAiBridge != null) localAiBridge.handleModelResult(resultCode, data);
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackupJson = "";
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_BACKUP_REQUEST) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new java.io.IOException("Tidak dapat membuka file tujuan");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingBackupJson = "";
                Toast.makeText(this, "Cadangan berhasil disimpan", Toast.LENGTH_LONG).show();
            } else if (requestCode == OPEN_BACKUP_REQUEST) {
                StringBuilder content = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new java.io.IOException("Tidak dapat membaca file");
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) content.append(new String(buffer, 0, n, StandardCharsets.UTF_8));
                }
                String quoted = JSONObject.quote(content.toString());
                if (web != null) web.evaluateJavascript("window.__reyRestoreText && window.__reyRestoreText(" + quoted + ")", null);
            }
        } catch (Exception ex) {
            Toast.makeText(this, "Gagal memproses cadangan: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (web == null || request == null) return;

        Uri origin = request.getOrigin();
        // Compare scheme and host separately: WebView may represent the origin
        // with a trailing slash, so strict string equality can reject a valid request.
        boolean trustedOrigin = origin != null
                && "https".equalsIgnoreCase(origin.getScheme())
                && "appassets.androidplatform.net".equalsIgnoreCase(origin.getHost());
        if (!trustedOrigin) {
            request.deny();
            return;
        }

        boolean requestsVideo = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                requestsVideo = true;
            }
        }
        if (!requestsVideo) {
            request.deny();
            return;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            return;
        }

        // Keep this specific request pending until the user answers the Android permission prompt.
        if (pendingCameraRequest != null && pendingCameraRequest != request) {
            pendingCameraRequest.deny();
        }
        pendingCameraRequest = request;
        requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != CAMERA_PERMISSION_REQUEST) return;

        PermissionRequest request = pendingCameraRequest;
        pendingCameraRequest = null;
        if (request == null) return;

        boolean granted = grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        } else {
            request.deny();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingCameraRequest != null) {
            pendingCameraRequest.deny();
            pendingCameraRequest = null;
        }
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        // Let the page close its current dialog/receipt first. Exit only when no dialog is open.
        web.evaluateJavascript("(function(){return window.__reyBackPressed ? window.__reyBackPressed() : false})()", value -> {
            if ("true".equals(value)) return;
            finish();
        });
    }
}
