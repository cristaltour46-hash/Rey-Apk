package id.reyshop.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import java.util.concurrent.Executors

/** Native bridge for optional on-device LiteRT-LM model. Model is imported once and kept privately. */
class LocalAiBridge(private val activity: Activity, private val webView: WebView) {
    companion object { const val MODEL_REQUEST = 6107 }
    private val worker = Executors.newSingleThreadExecutor()
    private val modelFile = File(activity.filesDir, "reyshop-model.litertlm")
    private var engine: Engine? = null
    private var conversation: com.google.ai.edge.litertlm.Conversation? = null
    @Volatile private var loading = false

    @JavascriptInterface fun status(): String = when {
        conversation != null -> "ready"
        modelFile.exists() -> "model_saved"
        else -> "model_missing"
    }

    @JavascriptInterface fun chooseModel() {
        activity.runOnUiThread {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/octet-stream"
                putExtra(Intent.EXTRA_TITLE, "Pilih model AI .litertlm")
            }
            activity.startActivityForResult(intent, MODEL_REQUEST)
        }
    }

    fun handleModelResult(resultCode: Int, data: Intent?) {
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        worker.execute {
            try {
                activity.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Berkas model tidak bisa dibaca" }
                    modelFile.outputStream().use { output -> input.copyTo(output) }
                }
                postResult("Model tersimpan. Memuat model…", false)
                loadModel()
            } catch (e: Exception) {
                modelFile.delete()
                postResult("Gagal mengimpor model: ${e.message ?: "berkas tidak valid"}", true)
            }
        }
    }

    @JavascriptInterface fun ask(question: String) {
        if (question.isBlank()) { postResult("Tulis pertanyaan terlebih dahulu.", true); return }
        worker.execute {
            try {
                if (conversation == null) loadModel()
                val answer = requireNotNull(conversation) { "Model belum siap" }.sendMessage(question).toString()
                postResult(answer, false)
            } catch (e: Exception) {
                postResult("AI lokal belum dapat menjawab: ${e.message ?: "gagal memuat model"}", true)
            }
        }
    }

    private fun loadModel() {
        if (conversation != null) return
        check(modelFile.exists() && modelFile.length() > 0) { "Pilih berkas model .litertlm terlebih dahulu" }
        if (loading) return
        loading = true
        var created: Engine? = null
        try {
            created = Engine(EngineConfig(modelPath = modelFile.absolutePath))
            created.initialize()
            val conv = created.createConversation()
            engine = created
            conversation = conv
        } catch (e: Exception) {
            try { created?.close() } catch (_: Exception) {}
            throw e
        } finally { loading = false }
    }

    private fun postResult(message: String, error: Boolean) {
        val quoted = JSONObject.quote(message)
        webView.post { webView.evaluateJavascript("window.__reyLocalAiResult && window.__reyLocalAiResult($quoted, $error)", null) }
    }
}
