PERBAIKAN TRANSAKSI BARANG BARU DAN STOK TIDAK CUKUP

- Form penjualan dan pembelian dapat membuat barang baru langsung dari kolom pilih barang manual: ketik nama barang, isi harga/unit, lalu tekan Tambah item.
- Barang baru disimpan ke master dengan stok awal 0. Pada penjualan, harga yang dimasukkan menjadi harga jual; pada pembelian, menjadi harga modal.
- Pembelian barang baru menambah stok sesuai qty transaksi.
- Penjualan dengan stok tidak cukup menampilkan konfirmasi/peringatan. Jika pengguna melanjutkan, transaksi disimpan dan stok dapat menjadi negatif agar kekurangan stok terlihat.
- Jika pengguna membatalkan konfirmasi, transaksi tidak disimpan dan stok transaksi lama (bila mengedit) dikembalikan.
- Fitur lain, form Hutang, halaman Laporan, dan workflow GitHub Actions tidak diubah.

Catatan: untuk barang baru yang dibuat dari penjualan, harga modal awal 0. Lengkapi harga modal di Setting bila diperlukan untuk perhitungan nilai aset/keuntungan.
Belum diuji melalui build APK atau perangkat Android.
