Rey Shop v30

Pembaruan:
1. Dashboard stok menipis hanya menampilkan barang dengan stok lebih dari nol.
2. Tombol aksi transaksi di halaman Penjualan, Pembelian, dan Laporan dibuat lebih ringkas dengan ikon.
3. Panel pemindai barcode pada Setting dipasang sticky di bagian atas konten saat halaman digulir.
4. Form Penjualan/Pembelian dimulai tanpa barang terpilih; memilih barang dari hasil pencarian manual langsung menambahkannya ke keranjang; qty dan harga/unit sejajar.
5. Form tambah/edit barang diurutkan: barcode, nama, satuan + stok, modal + jual, lalu batas stok minimum.
6. Pemindai hanya meminta format barcode batang EAN/UPC/Code 128/Code 39/ITF/Codabar; QR code tidak termasuk.

APK belum dikompilasi atau diuji langsung pada perangkat. Uji pemindaian di perangkat yang mendukung BarcodeDetector dan pastikan izin kamera aktif.
