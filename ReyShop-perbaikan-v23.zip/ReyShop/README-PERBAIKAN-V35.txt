REY SHOP - PERBAIKAN V35

Perubahan dari v34:
- Pencarian otomatis tabel tetap tersedia di seluruh tabel kecuali daftar barang pada keranjang Penjualan/Pembelian.
- Kolom pilih barang manual dikosongkan setelah barcode berhasil ditambahkan, termasuk pilihan barcode ganda.
- Form Hutang: nama pelanggan full width di atas; tanggal, nomor catatan, dan tombol scan pada baris metadata.
- Memperbaiki keranjang Hutang dengan tabel item, edit qty/harga, hapus item, dan total.
- Pencarian barcode pada laporan menggunakan pencocokan barcode yang tidak sensitif huruf besar/kecil serta normalisasi nama barang.

Catatan: Source diperiksa sintaks JavaScript dengan node --check dan aset HTML Android disamakan. APK belum dibangun atau diuji pada perangkat fisik.
