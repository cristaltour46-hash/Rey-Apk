REY SHOP v24 - PERBAIKAN FORM DAN BARCODE

Perubahan:
1. Tanggal, nomor transaksi, dan tombol scan barcode dalam satu baris horizontal; tombol scan paling kanan.
2. Jika barcode cocok dengan beberapa nama barang (mis. grosir/ecer), pilihan tampil sebagai popup di luar formulir dan otomatis tertutup setelah dipilih.
3. Kode internal tidak tampil pada form barang; nilai SKU lama tetap dipertahankan sebagai hidden input sehingga struktur data/cadangan kompatibel.
4. Setting memiliki pencarian barcode: barang ditemukan membuka form edit, barcode tidak ditemukan membuka form tambah dengan barcode terisi. Jika ada lebih dari satu kecocokan, pengguna memilih barang melalui popup.

Catatan: build dan uji kamera nyata perlu dilakukan melalui GitHub Actions dan perangkat Android.
