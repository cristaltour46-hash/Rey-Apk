REY SHOP v38 - PERBAIKAN FORM HUTANG

1. Tabel keranjang hutang dipadatkan agar kolom subtotal terlihat pada layar HP tanpa geser horizontal.
2. Scanner pada formulir hutang tetap aktif setelah barcode terbaca dan tidak ditutup otomatis setelah 1 menit.
3. Kamera tetap dapat ditutup manual melalui tombol Tutup kamera, dan dihentikan ketika berpindah halaman atau menutup formulir/modal.

Workflow GitHub Actions tidak diubah. APK belum dibangun atau diuji langsung pada perangkat.
