Perbaikan Gemini API Rey Shop

- Model diperbarui ke gemini-3.5-flash-lite.
- Memakai REST Interactions API: POST /v1beta/interactions.
- Mengirim API key lewat header x-goog-api-key.
- store:false dipakai agar interaksi tidak disimpan sebagai riwayat Interactions di server.
- Hanya pertanyaan umum yang dikirim; tidak ada stok, transaksi, omzet, hutang, atau identitas pelanggan yang disertakan.
- Pembatas lokal maksimal 30 panggilan berhasil per hari tetap dipertahankan. Ini bukan jaminan kuota gratis Google.
- API key di penyimpanan lokal perangkat hanya cocok untuk uji coba pribadi, bukan distribusi APK.

Build Android dan panggilan API langsung belum diuji pada perangkat.
