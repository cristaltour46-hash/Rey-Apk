Perbaikan Asisten Gemini
- Pertanyaan umum yang sekadar menyebut kata "barang" atau "produk" kini diarahkan ke Gemini, bukan ditolak oleh fondasi offline.
- Pertanyaan yang meminta data toko tetap diarahkan ke penjawab lokal agar data stok/transaksi tidak dikirim ke layanan AI.
- Tidak mengubah form Hutang, halaman Laporan, atau workflow GitHub Actions.
- Belum diuji dengan build APK atau panggilan API langsung.

Perbaikan lanjutan: klasifikasi pertanyaan data diperketat agar kata umum seperti “barang ... mudah ditemukan” tidak dianggap otomatis sebagai pertanyaan data toko. Pertanyaan contoh tersebut sekarang diarahkan ke Gemini.
