PERBAIKAN REY SHOP v32.3

Dashboard:
- Nilai transaksi tidak lagi tampil di atas grafik; sentuh batang untuk melihat tanggal, jenis, dan nilai transaksi.
- Grafik Hari ini dipusatkan.
- Grafik 30 hari dapat digeser horizontal. Zoom dua jari diaktifkan pada area grafik.

Laporan:
- Form ringkasan transaksi per barang ditata ulang: tanggal dua kolom, jenis transaksi di bawah tanggal, input barang sejajar dengan tombol scan.
- Pilihan barang hanya diambil dari barang yang memiliki transaksi untuk jenis dan periode terpilih.
- Dropdown saran tidak dibuka jika input kosong.
- Scan sukses menutup kamera dan menampilkan ringkasan barang.

Setting/navigasi:
- Kamera scan dihentikan dan panel dilepas saat berpindah halaman, agar panel kamera tidak tertinggal di halaman Laporan.

Catatan: periksa hasil di APK setelah build Android. Workflow GitHub Actions tidak diubah.
