PERBAIKAN REY SHOP V22

Fitur yang ditambahkan:
1. Kolom Cari pada tabel yang tersedia, termasuk daftar barang, stok menipis, transaksi, laporan, keranjang dan rincian transaksi; pencarian menyaring baris tabel dan tetap memakai pagination maksimal 10 baris.
2. Validasi barang baru/edit: kombinasi nama barang dan barcode/kode yang sama tidak boleh didaftarkan dua kali. Barcode yang sama untuk nama barang berbeda tetap diizinkan agar variasi grosir dapat dipilih ketika scan.
3. Daftar barang dan transaksi diurutkan terbaru lebih dahulu.
4. Jika hasil scan barcode cocok dengan lebih dari satu barang, aplikasi menampilkan tombol pilihan nama barang, stok, dan harga sebelum masuk ke keranjang.
5. Tombol Kirim WhatsApp pada struk membagikan rincian transaksi sebagai teks melalui menu berbagi Android; pilih WhatsApp dan kontak tujuan.

Catatan:
- Perubahan Android memerlukan build APK baru dari folder android-wrapper.
- Pemeriksaan sintaks JavaScript dan struktur ZIP dilakukan. APK belum dibangun atau diuji di perangkat fisik pada lingkungan ini.
