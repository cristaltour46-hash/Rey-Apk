REY SHOP V13 - PERBAIKAN PEMBACA BARCODE

Perubahan: jika BarcodeDetector bawaan Android/WebView tidak menemukan kode setelah beberapa waktu atau mengalami error, aplikasi beralih ke pembaca ZXing alternatif. Ini mengatasi kondisi umum ketika API native tersedia tetapi tidak membaca barcode pada WebView tertentu. Pembaca alternatif membutuhkan koneksi internet saat pustaka dimuat.

Paket sumber dan APK tetap perlu dibangun melalui GitHub Actions, lalu diuji langsung di perangkat Android. Pastikan izin kamera diberikan, barcode bersih/terang, dan kamera fokus.
