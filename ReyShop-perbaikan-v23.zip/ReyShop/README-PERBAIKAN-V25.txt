REY SHOP v25 — PERBAIKAN DASHBOARD DAN LAPORAN

Perubahan:
1. Header diberi ruang aman tambahan untuk mengurangi tertutupnya bagian atas oleh status bar Android.
2. Transaksi terbaru dipindahkan ke atas peringatan stok menipis.
3. Kartu laba kotor diganti dengan grafik batang total penjualan dan pembelian hari ini.
4. Subjudul header diganti menjadi “Smart Warung by Rayshaka”.
5. Laporan menampilkan total aset modal stok (stok × harga modal), nilai jual seluruh stok (stok × harga jual), dan estimasi keuntungan stok.

Data persediaan memakai field yang sudah ada (stock, cost, price); struktur database/localStorage tidak diubah.

Build melalui GitHub Actions menggunakan ReyShop-perbaikan-v25.zip. APK belum diuji pada perangkat fisik.

Update: nomor transaksi hutang memakai awalan KS dan detail hutang menyediakan aksi untuk membagikan bukti hutang sebagai gambar. Metode berbagi memakai AndroidShare bila tersedia; selain itu gambar PNG disimpan untuk dilampirkan manual ke WhatsApp.
