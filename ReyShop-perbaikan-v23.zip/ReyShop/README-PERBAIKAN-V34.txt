Rey Shop - Paket source perbaikan v34

Perubahan yang diterapkan:
1. Input jam disembunyikan dari formulir penjualan/pembelian; nilai jam transaksi tetap disimpan agar dapat ditampilkan pada tabel.
2. Menambah ruang bagian atas formulir.
3. Menyembunyikan kolom Qty dan Harga/Unit terpisah pada formulir penjualan/pembelian; qty dan harga tetap dapat disesuaikan di keranjang. Tombol Batal, Draft, dan Simpan dibuat horizontal dan berbeda warna. Rekomendasi barang tidak muncul saat input manual kosong.
4. Formulir hutang menggunakan pencarian barang manual/autocomplete, pemindaian barcode, keranjang multi-item, dan perubahan qty/harga per item. Catatan hutang tetap terpisah dari stok dan transaksi jual/beli.
5. Menu navigasi utama dipadatkan dalam satu baris horizontal yang dapat digeser jika layar terlalu sempit.

Pemeriksaan yang dilakukan: pemeriksaan sintaks JavaScript dengan node --check; HTML source utama dan asset WebView disinkronkan.
Batasan: APK belum dibangun atau diuji langsung di perangkat Android. Lakukan build melalui workflow GitHub Actions yang sudah ada; workflow tidak diubah.
