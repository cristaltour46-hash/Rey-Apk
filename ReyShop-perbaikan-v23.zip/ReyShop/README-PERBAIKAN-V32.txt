REY SHOP v32

Perubahan berdasarkan revisi v31.1:
- Menghapus kartu ringkasan Penjualan dan Pembelian dari Dashboard.
- Menghapus grafik perbandingan total Penjualan vs Pembelian.
- Grafik transaksi menampilkan batang Penjualan dan Pembelian per hari; pilihan dropdown Hari ini / 7 hari / 30 hari mengubah rentang grafik.
- Tombol scan dipindahkan ke samping input nama barang pada kartu Ringkasan transaksi per barang.
- Area kamera scan dibuat terpisah sebagai panel mengambang di bagian atas layar. Setelah barcode ditemukan, barang langsung dipilih dan ringkasan ditampilkan.
- Menambahkan tanggal awal dan akhir khusus untuk Ringkasan transaksi per barang.
- Menghapus kata “(autocomplete)” dari label pilihan barang.

Validasi yang dilakukan: sintaks JavaScript lolos `node --check`; isi paket ZIP divalidasi. APK belum dibangun atau diuji pada perangkat Android, sehingga kamera dan tampilan layar tetap perlu diuji setelah build APK.
