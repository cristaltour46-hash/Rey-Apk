# Rey Shop v9

Pembaruan dari v7:
- Tata letak responsif untuk layar HP, formulir, tabel, tombol, dan modal.
- Tombol kembali Android menutup dialog/struk lebih dahulu; struk ditampilkan di dalam aplikasi agar tidak membuka jendela baru.
- Riwayat transaksi diringkas per nomor transaksi, dengan tombol Lihat untuk rincian item.
- Pemindaian barcode melanjutkan sesi scan setelah barang masuk ke keranjang; tekan Tutup kamera untuk berhenti.
- Hasil scan memilih barang pada input manual; kolom barang mendukung autocomplete berdasarkan nama/barcode.
- Nominal pembayaran opsional dan perhitungan kembalian; dicetak pada struk bila diisi.
- Ikon aplikasi Rey Shop.

Build APK: unggah isi paket builder ke root repository GitHub, lalu jalankan Actions > Build Rey Shop APK > Run workflow. APK yang dihasilkan adalah debug APK untuk pengujian.
