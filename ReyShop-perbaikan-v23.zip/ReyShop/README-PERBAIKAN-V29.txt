Rey Shop v29
- Ikon navigasi bawah diperbarui.
- Nama barang ditampilkan dalam Title Case pada tabel, pilihan barang, dan form.
- Gambar struk PNG dirancang ulang dengan tinggi dinamis, nama barang multi-baris, dan jarak antarelemen untuk mencegah tulisan tumpang tindih.
- APK harus dibangun melalui GitHub Actions dan diuji pada perangkat Android.
