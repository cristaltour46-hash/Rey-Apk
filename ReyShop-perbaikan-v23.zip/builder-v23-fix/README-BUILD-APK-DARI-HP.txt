REY SHOP v23 - BUILDER APK (PERBAIKAN EKSTRAKSI)

Paket ini memperbaiki workflow yang gagal karena tidak menemukan folder android-wrapper.
Workflow mencari folder android-wrapper di mana pun letaknya setelah ZIP sumber diekstrak, lalu memeriksa file Gradle wajib sebelum build.

CARA PAKAI:
1. Ekstrak ZIP builder ini.
2. Unggah file ReyShop-perbaikan-v23.zip ke folder utama (root) repositori GitHub.
3. Salin folder .github/workflows/build-apk.yml ke repositori dengan jalur yang sama: .github/workflows/build-apk.yml. Jika sudah ada, ganti file workflow lama.
4. Commit changes.
5. Buka tab Actions dan jalankan workflow Build Rey Shop APK.
6. Jika berhasil, buka hasil run dan unduh artifact Rey-Shop-v23-debug-APK.

PENTING:
- Pastikan nama ZIP tepat: ReyShop-perbaikan-v23.zip
- Workflow akan memeriksa isi ZIP dan menampilkan struktur folder bila android-wrapper tidak ditemukan.
- Keberhasilan build belum menjamin semua fitur telah diuji di perangkat Android.
