REY SHOP V22 — BUILD APK

1. Unggah semua isi paket builder ini ke repository GitHub milik Anda, atau gunakan workflow build-apk.yml di folder .github/workflows.
2. Jalankan workflow Build APK melalui tab Actions GitHub.
3. Setelah workflow selesai, unduh artifact APK yang dihasilkan dan pasang di HP Android.
4. Uji pencarian tabel, validasi nama+barcode ganda, urutan data terbaru, pilihan barang saat barcode sama, serta tombol Kirim WhatsApp pada struk.

Kode sumber terbaru tersedia di ReyShop-perbaikan-v22.zip. Ekstrak isi ZIP tersebut jika ingin mengembangkan aplikasi secara lokal.
Catatan: APK belum dikompilasi atau diuji pada perangkat fisik dari lingkungan ini.
