REY SHOP — MEMBANGUN APK DARI HP ANDROID (TANPA KOMPUTER)

Paket ini menggunakan GitHub Actions untuk membangun APK di cloud. Anda perlu akun GitHub dan koneksi internet. APK belum ada di dalam ZIP ini; APK baru tersedia setelah workflow berhasil.

LANGKAH:
1. Ekstrak paket ini di HP dengan aplikasi pengelola ZIP.
2. Buka https://github.com dan masuk/daftar akun.
3. Buat repository baru, misalnya bernama rey-shop-build. Pilih Private jika ingin sumber kode tidak publik.
4. Di repository, pilih Add file > Upload files. Unggah file ReyShop-perbaikan-kamera.zip dari paket ini, lalu Commit changes.
5. Buat file baru melalui Add file > Create new file. Nama file harus tepat:
   .github/workflows/build-apk.yml
6. Buka file build-apk.yml dari paket ini dengan editor teks, salin seluruh isinya, tempel ke file baru di GitHub, lalu Commit changes.
   Jika workflow tidak berjalan otomatis, buka tab Actions, pilih “Build Rey Shop APK”, lalu tekan “Run workflow”.
7. Tunggu workflow selesai dengan tanda hijau. Buka run terbaru, turun ke bagian Artifacts, lalu unduh “Rey-Shop-debug-APK”.
8. Ekstrak ZIP artifact yang diunduh. Di dalamnya ada app-debug.apk. Buka file APK dan ikuti prompt instalasi Android. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.

CATATAN PENTING:
- Build debug APK untuk pengujian, bukan APK rilis Play Store.
- Build yang sukses belum membuktikan kamera/barcode sudah berfungsi di HP. Uji dahulu setelah instalasi.
- Sebelum mengganti aplikasi lama, ekspor/cadangkan data Rey Shop melalui menu Setting jika tersedia.
- Jangan bagikan token, kata sandi, atau kredensial GitHub kepada siapa pun.
