REY SHOP v12 - PERBAIKAN PEMBACA BARCODE

Perbaikan:
- Scanner sekarang mencoba BarcodeDetector bawaan Android/Chrome terlebih dahulu, tanpa mengunduh pustaka eksternal.
- Jika BarcodeDetector tidak tersedia, aplikasi memakai ZXing dengan dua alamat CDN sebagai cadangan.
- Alur scan dipakai bersama untuk form tambah barang, penjualan, dan pembelian.
- Area pratinjau kamera diperbesar dan kamera tetap aktif untuk scan berulang.

Catatan: BarcodeDetector tidak tersedia di semua versi WebView. Pada perangkat seperti itu, koneksi internet dibutuhkan untuk memuat ZXing. Izinkan akses kamera untuk Rey Shop.
